module PowerAssert
  VERSION = "0.2.6"
end
